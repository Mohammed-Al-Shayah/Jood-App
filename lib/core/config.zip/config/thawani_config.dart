class ThawaniConfig {
  const ThawaniConfig._();

  static const String apiKey = String.fromEnvironment(
    'THAWANI_API_KEY',

    // defaultValue: 'rRQ26GcsZzoEhbrP2HZvLYDbn9C9et',
    defaultValue: 'yRrRIT84UmfsR4fvQ1MCzq0QIDcECb',
  );

  static const String publishableApiKey = String.fromEnvironment(
    'THAWANI_PUBLISHABLE_KEY',
    defaultValue: 'x0huwSCEtlzJqX4ZCnCpMwUTLfnROJ',
    // defaultValue: 'HGvTMLDssJghr9tlN9gr4DVYt0qyBy',
  );

  static const bool isTestMode =
      String.fromEnvironment('THAWANI_TEST_MODE', defaultValue: 'false') ==
      'false';

  static bool get isConfigured =>
      apiKey.isNotEmpty && publishableApiKey.isNotEmpty;
}
